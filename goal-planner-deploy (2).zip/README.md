# 理財目標規劃器

以 PV、FV、PMT 為核心的理財目標試算網站。純靜態單頁，index.html 位於最外層，無需建置。

## 部署到 Cloudflare Pages（拖曳上傳）
1. Cloudflare Dashboard → Workers & Pages → Create → Pages → Upload assets
2. 把「整個資料夾」或「zip 檔」拖進去（index.html 必須在最外層）
3. Deploy 完成後即得到 https://<專案名>.pages.dev

## 部署到 GitHub + Cloudflare
1. 將本資料夾內所有檔案推上 GitHub repo 的根目錄
2. Cloudflare → Pages → Connect to Git → 選 repo
3. Build command 留空，Build output directory 留空（或填 `/`）

本工具僅供試算與教育用途，不構成投資建議。
